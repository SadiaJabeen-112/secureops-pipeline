# 🔐 SecureOps Pipeline — Azure DevOps CI/CD with Zero Trust

> A production-grade secure deployment pipeline built on Azure.
> Containerised static site deployed via Azure DevOps with Key Vault secrets,
> Managed Identity, NSG-hardened VNet, hardened Linux build agent,
> and full Azure Monitor observability.

---

## 🏗️ Architecture Overview

```
Developer → Git Push
    ↓
Azure DevOps Pipeline
    ↓
Stage 1: Build — Linux Agent (Hardened Ubuntu VM)
    ↓
Stage 2: Docker Build + Push → Azure Container Registry
    ↓
Stage 3: Security Scan (Trivy)
    ↓
Stage 4: Approval Gate (Manual Review)
    ↓
Stage 5: Deploy → Azure Container Instance
    ↓
Azure Monitor + Log Analytics (Observability)
```

---

## 🌐 Network Architecture (CCNA Applied)

```
Azure VNet: 10.0.0.0/16
├── Subnet: web-subnet     10.0.1.0/24  → Container Instance
├── Subnet: mgmt-subnet    10.0.2.0/24  → Build Agent VM
└── Subnet: ops-subnet     10.0.3.0/24  → Key Vault + Monitor
```

**NSG Rules:**
- web-subnet: Allow 80/443 inbound, Deny all else
- mgmt-subnet: Allow SSH from admin IP only, Deny all else
- ops-subnet: Allow internal only, Deny all internet inbound

---

## 🛠️ Technologies Used

| Technology        | Purpose                              | Cert Coverage |
|-------------------|--------------------------------------|---------------|
| Linux (Ubuntu)    | Hardened CI/CD build agent           | RHCSA         |
| Docker            | App containerisation                 | AZ-204        |
| Azure VNet + NSG  | Network isolation + security         | AZ-104 + CCNA |
| Azure Key Vault   | Secret management                    | AZ-204        |
| Managed Identity  | Passwordless auth to Key Vault       | AZ-204        |
| RBAC              | Least privilege access control       | AZ-104        |
| Azure DevOps      | CI/CD pipeline                       | AZ-400        |
| Azure Monitor     | Observability + alerting             | AZ-104        |
| Trivy             | Container vulnerability scanning     | AZ-400        |
| Bicep             | Infrastructure as Code               | AZ-400        |

---

## 📁 Repository Structure

```
secureops-pipeline/
├── app/
│   └── index.html              # Static site
├── docker/
│   └── Dockerfile              # Multi-stage build
├── infra/
│   ├── bicep/
│   │   └── main.bicep          # IaC — VNet, NSG, ACR, KV
│   └── nsg/
│       └── nsg-rules.json      # NSG rule definitions
├── pipeline/
│   └── azure-pipelines.yml     # Full CI/CD pipeline
├── scripts/
│   └── linux-hardening/
│       └── harden.sh           # Linux hardening script
└── docs/
    └── architecture.md         # Architecture decisions
```

---

## 🚀 Quick Start

### Prerequisites
- Azure subscription (free trial works)
- Azure CLI installed
- Azure DevOps account (free)
- Docker installed locally

### Step 1 — Deploy Infrastructure
```bash
az login
az group create --name secureops-rg --location uksouth
az deployment group create \
  --resource-group secureops-rg \
  --template-file infra/bicep/main.bicep
```

### Step 2 — Harden the Build Agent
```bash
chmod +x scripts/linux-hardening/harden.sh
sudo ./scripts/linux-hardening/harden.sh
```

### Step 3 — Connect Azure DevOps
1. Create project in Azure DevOps
2. Connect to this GitHub repo
3. Create pipeline from `pipeline/azure-pipelines.yml`
4. Link Key Vault to pipeline variable group
5. Run pipeline

---

## 🔐 Security Features

- ✅ Zero hardcoded secrets — all via Key Vault
- ✅ Managed Identity — no service principal passwords
- ✅ NSG deny-all default — explicit allow only
- ✅ RBAC least privilege — each component minimal access
- ✅ Container image scanning — Trivy in pipeline
- ✅ Linux hardened — immutable files, audit rules, nftables
- ✅ Approval gate — no auto-deploy to production
- ✅ Full audit trail — Azure Monitor logs all actions

---

## 📊 Azure Monitor Alerts Configured

| Alert                        | Threshold    | Action          |
|------------------------------|--------------|-----------------|
| Pipeline failure             | Any failure  | Email notify    |
| Container CPU > 80%          | 5 min        | Email notify    |
| NSG rule change detected     | Any change   | Email notify    |
| Key Vault access denied      | Any denial   | Email notify    |
| VM SSH login                 | Any login    | Log + notify    |

---

## 👩‍💻 Author

**Sadia Jabeen**
Cloud & DevOps Professional | Hyderabad, India
4x Microsoft Azure Certified | CCNA
[LinkedIn](https://linkedin.com/in/sadiajabeen112) | [Portfolio](https://sadiajabeen112.github.io)

---

## 📝 License
MIT — free to use, learn from, and build upon.
