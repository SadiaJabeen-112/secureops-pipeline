#!/bin/bash
# ════════════════════════════════════════════════
# SecureOps Pipeline — Linux Hardening Script
# Hardens Ubuntu/RHEL build agent for CI/CD use
# Run as root: sudo ./harden.sh
# ════════════════════════════════════════════════

set -euo pipefail

# Colours
RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'
BLUE='\033[0;34m'; CYAN='\033[0;36m'; NC='\033[0m'

log()  { echo -e "${GREEN}[✓]${NC} $1"; }
warn() { echo -e "${YELLOW}[!]${NC} $1"; }
info() { echo -e "${CYAN}[→]${NC} $1"; }
fail() { echo -e "${RED}[✗]${NC} $1"; exit 1; }

echo -e "\n${BLUE}════════════════════════════════════════${NC}"
echo -e "${BLUE}  SecureOps — Linux Hardening Script${NC}"
echo -e "${BLUE}════════════════════════════════════════${NC}\n"

# ── CHECK ROOT ──────────────────────────────────
[[ $EUID -ne 0 ]] && fail "Run this script as root: sudo ./harden.sh"
log "Running as root"

# ── DETECT OS ───────────────────────────────────
if [ -f /etc/redhat-release ]; then
    OS="rhel"
    PKG="dnf"
elif [ -f /etc/debian_version ]; then
    OS="ubuntu"
    PKG="apt-get"
else
    fail "Unsupported OS"
fi
log "Detected OS: $OS"

# ══════════════════════════════════════════════
# 1. SYSTEM UPDATE
# ══════════════════════════════════════════════
info "Updating system packages..."
$PKG update -y -q
$PKG upgrade -y -q
log "System updated"

# ══════════════════════════════════════════════
# 2. SSH HARDENING
# ══════════════════════════════════════════════
info "Hardening SSH configuration..."

SSH_CONFIG="/etc/ssh/sshd_config"
cp $SSH_CONFIG ${SSH_CONFIG}.backup.$(date +%Y%m%d)

# Apply hardened SSH settings
cat >> $SSH_CONFIG << 'SSHEOF'

# ── SecureOps SSH Hardening ──────────────────
Protocol 2
PermitRootLogin no
PasswordAuthentication no
PubkeyAuthentication yes
PermitEmptyPasswords no
X11Forwarding no
MaxAuthTries 3
LoginGraceTime 30
ClientAliveInterval 300
ClientAliveCountMax 2
AllowAgentForwarding no
AllowTcpForwarding no
Banner /etc/ssh/banner
SSHEOF

# SSH banner
cat > /etc/ssh/banner << 'BANNEREOF'
╔══════════════════════════════════════════════════╗
║  SecureOps Build Agent — Authorised Access Only  ║
║  All activity is monitored and logged            ║
╚══════════════════════════════════════════════════╝
BANNEREOF

systemctl restart sshd
log "SSH hardened — root login disabled, password auth disabled"

# ══════════════════════════════════════════════
# 3. FIREWALL — nftables
# ══════════════════════════════════════════════
info "Configuring nftables firewall..."

# Install nftables
$PKG install -y nftables -q

# Write nftables config
cat > /etc/nftables.conf << 'NFTEOF'
#!/usr/sbin/nft -f
# SecureOps nftables configuration

flush ruleset

table inet filter {
    chain input {
        type filter hook input priority 0; policy drop;

        # Allow established and related connections
        ct state established,related accept

        # Allow loopback
        iifname "lo" accept

        # Allow SSH from specific subnet only (update with your admin IP)
        tcp dport 22 ip saddr 10.0.2.0/24 accept

        # Allow HTTP/HTTPS for web traffic
        tcp dport { 80, 443 } accept

        # Allow ICMP (ping) for monitoring
        ip protocol icmp accept

        # Log and drop everything else
        log prefix "nftables-drop: " drop
    }

    chain forward {
        type filter hook forward priority 0; policy drop;
    }

    chain output {
        type filter hook output priority 0; policy accept;
    }
}
NFTEOF

systemctl enable nftables
systemctl start nftables
log "nftables firewall configured — default deny inbound"

# ══════════════════════════════════════════════
# 4. IMMUTABLE FILES — chattr
# ══════════════════════════════════════════════
info "Setting immutable flags on critical files..."

IMMUTABLE_FILES=(
    "/etc/passwd"
    "/etc/shadow"
    "/etc/group"
    "/etc/sudoers"
    "/etc/hosts"
    "/etc/resolv.conf"
    "/etc/nftables.conf"
)

for f in "${IMMUTABLE_FILES[@]}"; do
    if [ -f "$f" ]; then
        chattr +i "$f"
        log "Immutable: $f"
    fi
done

# Append-only for log files
APPEND_ONLY_DIRS=(
    "/var/log/auth.log"
    "/var/log/syslog"
)

for f in "${APPEND_ONLY_DIRS[@]}"; do
    if [ -f "$f" ]; then
        chattr +a "$f"
        log "Append-only: $f"
    fi
done

# ══════════════════════════════════════════════
# 5. AUDIT RULES — auditctl
# ══════════════════════════════════════════════
info "Configuring kernel audit rules..."

$PKG install -y auditd -q
systemctl enable auditd
systemctl start auditd

cat > /etc/audit/rules.d/secureops.rules << 'AUDITEOF'
# SecureOps Audit Rules

# Monitor authentication files
-w /etc/passwd -p wa -k identity_changes
-w /etc/shadow -p wa -k identity_changes
-w /etc/group -p wa -k identity_changes
-w /etc/sudoers -p wa -k sudoers_changes

# Monitor SSH
-w /etc/ssh/sshd_config -p wa -k ssh_config_change
-w /var/log/auth.log -p wa -k auth_log

# Monitor privilege escalation
-a always,exit -F arch=b64 -S setuid -S setgid -k privilege_escalation
-w /bin/su -p x -k privilege_escalation
-w /usr/bin/sudo -p x -k privilege_escalation

# Monitor network config changes
-w /etc/nftables.conf -p wa -k firewall_change
-w /etc/hosts -p wa -k network_change

# Monitor Docker activity
-w /usr/bin/docker -p x -k docker_activity
-w /var/lib/docker -p wa -k docker_data

# Monitor cron
-w /etc/cron.d -p wa -k cron_changes
-w /var/spool/cron -p wa -k cron_changes

# Record all failed login attempts
-a always,exit -F arch=b64 -S open -F exit=-EACCES -k access_denied
AUDITEOF

service auditd restart
log "Audit rules configured — monitoring identity, privilege escalation, Docker, network"

# ══════════════════════════════════════════════
# 6. DISABLE UNUSED SERVICES
# ══════════════════════════════════════════════
info "Disabling unused services..."

DISABLE_SERVICES=(
    "cups"
    "bluetooth"
    "avahi-daemon"
    "rpcbind"
    "nfs-server"
    "telnet"
)

for svc in "${DISABLE_SERVICES[@]}"; do
    if systemctl is-active --quiet $svc 2>/dev/null; then
        systemctl stop $svc
        systemctl disable $svc
        log "Disabled: $svc"
    fi
done

# ══════════════════════════════════════════════
# 7. KERNEL SECURITY PARAMETERS — sysctl
# ══════════════════════════════════════════════
info "Applying kernel security parameters via sysctl..."

cat > /etc/sysctl.d/99-secureops.conf << 'SYSCTLEOF'
# SecureOps Kernel Hardening

# Disable IP forwarding (not a router)
net.ipv4.ip_forward = 0

# Disable ICMP redirects
net.ipv4.conf.all.accept_redirects = 0
net.ipv4.conf.all.send_redirects = 0
net.ipv6.conf.all.accept_redirects = 0

# Enable SYN flood protection
net.ipv4.tcp_syncookies = 1

# Disable source routing
net.ipv4.conf.all.accept_source_route = 0

# Log martian packets
net.ipv4.conf.all.log_martians = 1

# Disable core dumps for SUID programs
fs.suid_dumpable = 0

# Restrict /proc access
kernel.dmesg_restrict = 1
kernel.kptr_restrict = 2

# Randomise memory layout (ASLR)
kernel.randomize_va_space = 2
SYSCTLEOF

sysctl -p /etc/sysctl.d/99-secureops.conf
log "Kernel security parameters applied"

# ══════════════════════════════════════════════
# 8. FILE PERMISSIONS AUDIT
# ══════════════════════════════════════════════
info "Checking sensitive file permissions..."

chmod 600 /etc/shadow
chmod 644 /etc/passwd
chmod 440 /etc/sudoers
chmod 700 /root
log "File permissions corrected"

# ══════════════════════════════════════════════
# HARDENING SUMMARY
# ══════════════════════════════════════════════
echo -e "\n${BLUE}════════════════════════════════════════${NC}"
echo -e "${GREEN}  Hardening Complete — Summary${NC}"
echo -e "${BLUE}════════════════════════════════════════${NC}"
echo -e "${GREEN}[✓]${NC} System updated"
echo -e "${GREEN}[✓]${NC} SSH hardened — no root, no passwords"
echo -e "${GREEN}[✓]${NC} nftables firewall — default deny"
echo -e "${GREEN}[✓]${NC} Critical files set immutable (chattr +i)"
echo -e "${GREEN}[✓]${NC} Audit rules configured (auditctl)"
echo -e "${GREEN}[✓]${NC} Unused services disabled"
echo -e "${GREEN}[✓]${NC} Kernel parameters hardened (sysctl)"
echo -e "${GREEN}[✓]${NC} File permissions corrected"
echo -e "\n${YELLOW}[!]${NC} IMPORTANT: Reboot recommended"
echo -e "${YELLOW}[!]${NC} Verify SSH access BEFORE closing this session"
echo -e "${YELLOW}[!]${NC} Update admin IP in nftables if needed\n"
