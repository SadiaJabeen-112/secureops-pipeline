# SecureOps Pipeline — 2 Day Build Guide

## Prerequisites — Do This First
- Azure free trial account → portal.azure.com
- Azure CLI installed → https://learn.microsoft.com/cli/azure/install-azure-cli
- Docker Desktop installed → docker.com
- Azure DevOps free account → dev.azure.com
- GitHub account → github.com
- VS Code recommended

---

# DAY 1 — Infrastructure + Linux + Docker

## Step 1 — Create GitHub Repository (15 min)

1. Go to github.com → New repository
2. Name it: secureops-pipeline
3. Set to Public
4. Upload all project files from this folder
5. Your repo URL: github.com/SadiaJabeen-112/secureops-pipeline

## Step 2 — Deploy Azure Infrastructure (20 min)

Open terminal and run:

```bash
# Login to Azure
az login

# Create resource group
az group create \
  --name secureops-rg \
  --location uksouth

# Get your current IP for SSH access
MY_IP=$(curl -s ifconfig.me)
echo "Your IP: $MY_IP"

# Deploy infrastructure
az deployment group create \
  --resource-group secureops-rg \
  --template-file infra/bicep/main.bicep \
  --parameters adminIpAddress=$MY_IP

# Save the outputs — you will need these
az deployment group show \
  --resource-group secureops-rg \
  --name main \
  --query properties.outputs
```

What this creates:
- Azure VNet with 3 subnets (10.0.0.0/16)
- 3 NSGs — web, mgmt, ops
- Azure Container Registry
- Key Vault
- Log Analytics Workspace

## Step 3 — Create Build Agent VM (15 min)

```bash
# Create VM in management subnet
az vm create \
  --resource-group secureops-rg \
  --name secureops-build-agent \
  --image Ubuntu2204 \
  --size Standard_B1s \
  --admin-username azureuser \
  --ssh-key-values ~/.ssh/id_rsa.pub \
  --vnet-name secureops-vnet \
  --subnet mgmt-subnet \
  --public-ip-sku Standard \
  --nsg "" \
  --output table

# Get VM public IP
VM_IP=$(az vm list-ip-addresses \
  --resource-group secureops-rg \
  --name secureops-build-agent \
  --query "[0].virtualMachine.network.publicIpAddresses[0].ipAddress" \
  --output tsv)

echo "VM IP: $VM_IP"
```

## Step 4 — Harden the Linux Build Agent (20 min)

```bash
# SSH into the VM
ssh azureuser@$VM_IP

# Upload hardening script
scp scripts/linux-hardening/harden.sh azureuser@$VM_IP:~/

# SSH in and run hardening
ssh azureuser@$VM_IP
chmod +x harden.sh
sudo ./harden.sh

# Verify hardening
sudo lsattr /etc/passwd        # Should show ----i-------
sudo auditctl -l               # Should show audit rules
sudo nft list ruleset          # Should show firewall rules
sudo sysctl kernel.dmesg_restrict  # Should show = 1
```

## Step 5 — Install Azure DevOps Agent on VM (15 min)

```bash
# Still SSH'd into the VM

# Install Docker
curl -fsSL https://get.docker.com -o get-docker.sh
sudo sh get-docker.sh
sudo usermod -aG docker azureuser

# Install Azure DevOps agent
mkdir ~/azagent && cd ~/azagent
wget https://vstsagentpackage.azureedge.net/agent/3.232.0/vsts-agent-linux-x64-3.232.0.tar.gz
tar zxvf vsts-agent-linux-x64-3.232.0.tar.gz

# Configure agent (you need your Azure DevOps PAT token)
./config.sh --url https://dev.azure.com/YOUR_ORG \
            --auth pat \
            --token YOUR_PAT_TOKEN \
            --pool Default \
            --agent secureops-agent

# Install and start as service
sudo ./svc.sh install
sudo ./svc.sh start

echo "Agent is running"
```

## Step 6 — Configure Key Vault Secrets (10 min)

```bash
# Back on your local machine

# Get ACR login server
ACR_NAME=$(az acr list --resource-group secureops-rg --query "[0].name" -o tsv)
ACR_SERVER=$(az acr show --name $ACR_NAME --query loginServer -o tsv)

# Get Key Vault name
KV_NAME=$(az keyvault list --resource-group secureops-rg --query "[0].name" -o tsv)

# Store secrets in Key Vault
az keyvault secret set --vault-name $KV_NAME --name "ACR-LOGIN-SERVER" --value $ACR_SERVER
az keyvault secret set --vault-name $KV_NAME --name "ACR-NAME" --value $ACR_NAME
az keyvault secret set --vault-name $KV_NAME --name "APPROVER-EMAIL" --value "your-email@gmail.com"
az keyvault secret set --vault-name $KV_NAME --name "RESOURCE-GROUP" --value "secureops-rg"

echo "Secrets stored in Key Vault"
```

## Step 7 — Test Docker Build Locally (10 min)

```bash
# On your local machine — test the build first
cd secureops-pipeline

# Build the image
docker build -t secureops-app:test -f docker/Dockerfile .

# Run it locally
docker run -d -p 8080:80 --name secureops-test secureops-app:test

# Open http://localhost:8080 — should show the deployed page
curl http://localhost:8080

# Clean up
docker stop secureops-test && docker rm secureops-test
```

---

# DAY 2 — Pipeline + Documentation + Publish

## Step 8 — Set Up Azure DevOps Project (20 min)

1. Go to dev.azure.com
2. Create new project: SecureOps-Pipeline
3. Go to Pipelines → Create Pipeline
4. Connect to GitHub → select secureops-pipeline repo
5. Choose "Existing Azure Pipelines YAML file"
6. Select: pipeline/azure-pipelines.yml

## Step 9 — Configure Variable Group + Key Vault (15 min)

In Azure DevOps:
1. Pipelines → Library → Variable Groups
2. Create group: secureops-keyvault-secrets
3. Enable "Link secrets from Azure Key Vault"
4. Select your Key Vault
5. Add variables: ACR-LOGIN-SERVER, ACR-NAME, APPROVER-EMAIL
6. Save

## Step 10 — Configure Service Connections (10 min)

In Azure DevOps:
1. Project Settings → Service Connections
2. New → Azure Resource Manager
3. Name: secureops-azure-connection
4. Select subscription → secureops-rg

5. New → Docker Registry
6. Name: secureops-acr-connection
7. Select Azure Container Registry → your ACR

## Step 11 — Configure Environment + Approval Gate (10 min)

In Azure DevOps:
1. Pipelines → Environments
2. Create: production
3. Click production → Approvals and checks
4. Add → Approvals
5. Add your email as approver
6. Timeout: 24 hours
7. Save

## Step 12 — Run the Pipeline (10 min)

1. Go to Pipelines → Run Pipeline
2. Branch: main
3. Watch each stage:
   - Build ✓
   - Docker Build & Push ✓
   - Security Scan ✓
   - Approval Gate — check your email, approve
   - Deploy ✓
4. Get the deployed URL from logs
5. Screenshot everything

## Step 13 — Configure Azure Monitor Alerts (15 min)

```bash
# Get Log Analytics workspace ID
WORKSPACE_ID=$(az monitor log-analytics workspace show \
  --resource-group secureops-rg \
  --workspace-name secureops-logs \
  --query customerId -o tsv)

echo "Workspace ID: $WORKSPACE_ID"

# Create action group for email alerts
az monitor action-group create \
  --resource-group secureops-rg \
  --name secureops-alerts \
  --short-name soalerts \
  --email-receiver name=admin email=your-email@gmail.com
```

In Azure Portal:
1. Go to your Container Instance
2. Monitoring → Alerts → New Alert Rule
3. Add condition: CPU percentage > 80%
4. Add action group: secureops-alerts
5. Save

## Step 14 — Document + Publish (60 min)

### GitHub
1. Make sure all files are pushed
2. Add screenshots to README
3. Update README with your actual deployed URL
4. Add topics: azure, devops, docker, linux, cicd, security

### LinkedIn Post (use the template below)
### Medium Article (use the outline below)
### Resume Update (use the bullet points below)

---

## Resume Bullet Points — Copy These

**Projects Section:**

SecureOps Pipeline — Azure DevOps CI/CD with Zero Trust Security
- Designed and built a production-grade CI/CD pipeline on Azure deploying a containerised application via Azure DevOps with 5-stage pipeline including security scanning and manual approval gates
- Implemented Zero Trust network architecture — 3-subnet VNet (10.0.0.0/16) with separate NSGs enforcing default-deny inbound rules, mapped from CCNA subnetting knowledge to Azure VNet design
- Hardened Linux build agent using nftables firewall, chattr immutable file flags, auditctl kernel audit rules, and sysctl security parameters — reducing attack surface before any pipeline code runs
- Eliminated hardcoded secrets using Azure Key Vault with Managed Identity authentication — pipeline variables linked directly to Key Vault with zero service principal credentials
- Integrated Trivy container vulnerability scanner into pipeline — blocking deployment on any CRITICAL CVE detection
- Configured Azure Monitor with Log Analytics — 5 alert rules covering pipeline failures, NSG changes, Key Vault access denials, and container resource thresholds
- Technologies: Linux, Docker, Azure DevOps, Azure VNet/NSG, Key Vault, Managed Identity, RBAC, Azure Monitor, Bicep IaC, Trivy

---

## LinkedIn Post Template

I just finished building my first real cloud infrastructure project from scratch.

Not a tutorial. Not a guided lab. A real production-grade CI/CD pipeline on Azure with Zero Trust security.

Here is what I built in 2 days 👇

The project: SecureOps Pipeline
A static site deployed via Azure DevOps with full security baked in at every layer.

What is inside:

Linux — hardened Ubuntu build agent (nftables, chattr, auditctl, sysctl)
Docker — multi-stage Dockerfile, non-root container, security headers
Azure VNet — 3 subnets, 3 NSGs, default-deny inbound (CCNA applied to Azure)
Key Vault + Managed Identity — zero hardcoded secrets anywhere in the pipeline
Azure DevOps — 5 stage pipeline with Trivy scanning and manual approval gate
Azure Monitor — 5 alert rules covering security events and resource thresholds
Bicep IaC — entire infrastructure deployed as code in one command

Every cert I hold is represented in this project.
AZ-900 concepts, AZ-104 infrastructure, AZ-204 Key Vault and Managed Identity, AZ-400 pipeline design, CCNA network architecture.

GitHub repo is live. Link in comments.

What would you add to make it more production-ready?

#Azure #DevOps #Linux #Docker #CCNA #AZ400 #CloudSecurity #ZeroTrust #OpenToWork #Hyderabad

---

## Medium Article Outline

Title: How I Built a Production-Grade Secure CI/CD Pipeline on Azure in 2 Days

Section 1: The Problem I Was Solving
Section 2: Architecture Overview (include diagram)
Section 3: Day 1 Part 1 — Network Architecture (CCNA meets Azure)
Section 4: Day 1 Part 2 — Linux Hardening (the 8 things I did)
Section 5: Day 1 Part 3 — Docker Multi-Stage Build
Section 6: Day 2 Part 1 — The Pipeline (5 stages explained)
Section 7: Day 2 Part 2 — Key Vault + Managed Identity (no more hardcoded secrets)
Section 8: Day 2 Part 3 — Azure Monitor (how I know when things break)
Section 9: What Each Cert Contributed to This Project
Section 10: What I Would Do Differently
Section 11: GitHub Repo + Next Steps
