// ════════════════════════════════════════════════
// SecureOps Pipeline — Azure Infrastructure (Bicep)
// Deploys: VNet, Subnets, NSGs, ACR, Key Vault,
//          Log Analytics, Azure Monitor
// ════════════════════════════════════════════════

targetScope = 'resourceGroup'

// ── PARAMETERS ──────────────────────────────────
@description('Location for all resources')
param location string = resourceGroup().location

@description('Project prefix for naming')
param prefix string = 'secureops'

@description('Admin IP for SSH access — your IP only')
param adminIpAddress string

@description('Environment tag')
param environment string = 'dev'

// ── VARIABLES ───────────────────────────────────
var vnetName          = '${prefix}-vnet'
var webSubnetName     = 'web-subnet'
var mgmtSubnetName    = 'mgmt-subnet'
var opsSubnetName     = 'ops-subnet'
var webNsgName        = '${prefix}-web-nsg'
var mgmtNsgName       = '${prefix}-mgmt-nsg'
var opsNsgName        = '${prefix}-ops-nsg'
var acrName           = '${prefix}acr${uniqueString(resourceGroup().id)}'
var keyVaultName      = '${prefix}-kv-${uniqueString(resourceGroup().id)}'
var logWorkspaceName  = '${prefix}-logs'

// ── NSG — WEB SUBNET ────────────────────────────
resource webNsg 'Microsoft.Network/networkSecurityGroups@2023-04-01' = {
  name: webNsgName
  location: location
  tags: { environment: environment, project: prefix }
  properties: {
    securityRules: [
      {
        name: 'Allow-HTTP-Inbound'
        properties: {
          priority: 100
          protocol: 'Tcp'
          access: 'Allow'
          direction: 'Inbound'
          sourceAddressPrefix: 'Internet'
          sourcePortRange: '*'
          destinationAddressPrefix: '*'
          destinationPortRange: '80'
        }
      }
      {
        name: 'Allow-HTTPS-Inbound'
        properties: {
          priority: 110
          protocol: 'Tcp'
          access: 'Allow'
          direction: 'Inbound'
          sourceAddressPrefix: 'Internet'
          sourcePortRange: '*'
          destinationAddressPrefix: '*'
          destinationPortRange: '443'
        }
      }
      {
        name: 'Deny-All-Inbound'
        properties: {
          priority: 4096
          protocol: '*'
          access: 'Deny'
          direction: 'Inbound'
          sourceAddressPrefix: '*'
          sourcePortRange: '*'
          destinationAddressPrefix: '*'
          destinationPortRange: '*'
        }
      }
    ]
  }
}

// ── NSG — MANAGEMENT SUBNET ─────────────────────
resource mgmtNsg 'Microsoft.Network/networkSecurityGroups@2023-04-01' = {
  name: mgmtNsgName
  location: location
  tags: { environment: environment, project: prefix }
  properties: {
    securityRules: [
      {
        name: 'Allow-SSH-AdminOnly'
        properties: {
          priority: 100
          protocol: 'Tcp'
          access: 'Allow'
          direction: 'Inbound'
          sourceAddressPrefix: adminIpAddress
          sourcePortRange: '*'
          destinationAddressPrefix: '*'
          destinationPortRange: '22'
        }
      }
      {
        name: 'Deny-All-Inbound'
        properties: {
          priority: 4096
          protocol: '*'
          access: 'Deny'
          direction: 'Inbound'
          sourceAddressPrefix: '*'
          sourcePortRange: '*'
          destinationAddressPrefix: '*'
          destinationPortRange: '*'
        }
      }
    ]
  }
}

// ── NSG — OPS SUBNET ────────────────────────────
resource opsNsg 'Microsoft.Network/networkSecurityGroups@2023-04-01' = {
  name: opsNsgName
  location: location
  tags: { environment: environment, project: prefix }
  properties: {
    securityRules: [
      {
        name: 'Allow-VNet-Internal'
        properties: {
          priority: 100
          protocol: '*'
          access: 'Allow'
          direction: 'Inbound'
          sourceAddressPrefix: 'VirtualNetwork'
          sourcePortRange: '*'
          destinationAddressPrefix: 'VirtualNetwork'
          destinationPortRange: '*'
        }
      }
      {
        name: 'Deny-Internet-Inbound'
        properties: {
          priority: 4096
          protocol: '*'
          access: 'Deny'
          direction: 'Inbound'
          sourceAddressPrefix: 'Internet'
          sourcePortRange: '*'
          destinationAddressPrefix: '*'
          destinationPortRange: '*'
        }
      }
    ]
  }
}

// ── VIRTUAL NETWORK ─────────────────────────────
resource vnet 'Microsoft.Network/virtualNetworks@2023-04-01' = {
  name: vnetName
  location: location
  tags: { environment: environment, project: prefix }
  properties: {
    addressSpace: {
      addressPrefixes: ['10.0.0.0/16']
    }
    subnets: [
      {
        name: webSubnetName
        properties: {
          addressPrefix: '10.0.1.0/24'
          networkSecurityGroup: { id: webNsg.id }
        }
      }
      {
        name: mgmtSubnetName
        properties: {
          addressPrefix: '10.0.2.0/24'
          networkSecurityGroup: { id: mgmtNsg.id }
        }
      }
      {
        name: opsSubnetName
        properties: {
          addressPrefix: '10.0.3.0/24'
          networkSecurityGroup: { id: opsNsg.id }
        }
      }
    ]
  }
}

// ── AZURE CONTAINER REGISTRY ────────────────────
resource acr 'Microsoft.ContainerRegistry/registries@2023-01-01-preview' = {
  name: acrName
  location: location
  tags: { environment: environment, project: prefix }
  sku: { name: 'Basic' }
  properties: {
    adminUserEnabled: false
    publicNetworkAccess: 'Enabled'
  }
}

// ── LOG ANALYTICS WORKSPACE ──────────────────────
resource logWorkspace 'Microsoft.OperationalInsights/workspaces@2022-10-01' = {
  name: logWorkspaceName
  location: location
  tags: { environment: environment, project: prefix }
  properties: {
    sku: { name: 'PerGB2018' }
    retentionInDays: 30
  }
}

// ── KEY VAULT ────────────────────────────────────
resource keyVault 'Microsoft.KeyVault/vaults@2023-02-01' = {
  name: keyVaultName
  location: location
  tags: { environment: environment, project: prefix }
  properties: {
    sku: {
      family: 'A'
      name: 'standard'
    }
    tenantId: subscription().tenantId
    enableRbacAuthorization: true
    enableSoftDelete: true
    softDeleteRetentionInDays: 7
    enablePurgeProtection: false
    networkAcls: {
      defaultAction: 'Deny'
      bypass: 'AzureServices'
      virtualNetworkRules: [
        {
          id: '${vnet.id}/subnets/${opsSubnetName}'
        }
      ]
    }
  }
}

// ── OUTPUTS ──────────────────────────────────────
output vnetId          string = vnet.id
output acrLoginServer  string = acr.properties.loginServer
output keyVaultUri     string = keyVault.properties.vaultUri
output logWorkspaceId  string = logWorkspace.id
